CISC3003 Practice 05 - File Set (StudentID: DC228400, Name: Wang Yufeng)

1) Put ALL provided image files into the folder: images/
   Required filenames used by the HTML:
   - veermeer-view-of-house--background.jpg
   - mosaic-a.jpg ... mosaic-k.jpg

2) Use the 'student' files for submission / forum listing:
   - CISC3003-Practice05-DC228400.html
   - css/CISC3003-Practice05-DC228400.css

3) The "before" versions are kept for reference:
   - cisc3003-practice05-before.html
   - css/cisc3003-practice05-before.css

4) The "after" versions are also kept:
   - cisc3003-practice05-after.html
   - css/cisc3003-practice05-after.css

Note:
- HTML is unchanged except the <link rel="stylesheet"...> line.
- Folder "My Screen Shots" is included for you to save required screenshots.
